from categories import * 
from posts import * 
from images import *

db.create_all()

